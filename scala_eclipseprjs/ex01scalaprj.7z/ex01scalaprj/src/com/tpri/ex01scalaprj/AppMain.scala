package com.tpri.ex01scalaprj

object AppMain extends App {
  
  println("Hello! Welcome to Scala Programming with Syed Awase Khirni");
  val immutableVariable="Syed Awase Khirni"
  var mutableVariable="Syed Ameese Sadath"
  mutableVariable="Syed Azeez Al Asaad"
  // this would throw an error 
  //immutableVariable="Syeda Nayyirah Fathima"
  println("immutableVariable is:"+immutableVariable)
  println("mutableVariable is:"+mutableVariable)
  
  //custom function to evaluate type 
  def f[T](v:T)=v match{
    
    case _:Int => println("Integer Type")
    case _:Double=>println("Double Type")
    case _:String=>println("String Type")
    case _ =>println("Unknown Data Type")
    
  }
  
  //checking the type of immutableVariable and mutableVariable
  f(immutableVariable)
  f(mutableVariable)
  
}
package com.tpri.ex02scalaprj
import scala.collection.immutable.SortedSet
import scala.collection.mutable.Queue
/** * SCALA DEMO USING Collections
 */
object AppMain extends App {
  //defining a set
  val cartItems:Set[String]=Set("milk","eggs","bread","diaper","beer")
  val cricScore:SortedSet[Int]=SortedSet(12,3,14,26,29,67,78,18,59,39)
  //displaying the value of cartItems using for loops
  for(item<-cartItems){
    println(item)
  }
  //alternative way of implementing for loop
  println("________________________")
  cartItems.foreach((item:String)=>println(item))
  //using foreach for sorted items 
  cricScore.foreach((score:Int)=>println(score))
  /*   * Scala Lists demo    */ 
  var studentMathScore=List(11,8,23,24,18,19,14,15,19,22)
  var makeupMathScore=List(16,19,22)
  println("printing students scores for Math Exam")
  studentMathScore.foreach((element:Int)=>println(element))
  var ttlClassMathScore=studentMathScore++makeupMathScore
  println("Sorting the list:"+ttlClassMathScore.sorted)
  println("Reversing the order of the list:"+ttlClassMathScore.reverse)
  /**   * Scala Queue demo    */
  var movieTicketQ=Queue(3,1,4,5,6,7,9,3,12)
  println("Movie theatre ticket queue")
  movieTicketQ.foreach((element:Int)=>println(element))
  var firstManinQ=movieTicketQ.front
  println("first man in the queue:"+firstManinQ)
  var lastElement=movieTicketQ.last
  println("last element in the queue:"+lastElement)
  var enQ=movieTicketQ.enqueue(50)
  println(enQ)
  var dQ=movieTicketQ.dequeue
  println(dQ)
}
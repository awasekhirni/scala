package com.tpri.ex03scalaprj
import scala.reflect.runtime.universe._
//functions demo in Scala
object AppThreeMain extends App {
  def greet() {
    println("Welcome to Scala function demo without parameters")
  }
  def computeTax(salary: Int, taxPercent: Double): Double = {
    salary * taxPercent
  }
  println("the tax you pay for your annual salary is:" + computeTax(6700000, 0.18))
  //default arguments in Scala
  def printTaxAmount(salary: Int, taxPercent: Double = 0.18): Double = {
    salary * taxPercent
  }
  println("computing tax amount:" + printTaxAmount(8400000))
  //recursion demo in scala
  def factorial(n: Int): Int = n match {
    case 0 => 1
    case _ => n * factorial(n - 1)
  }
  println("the factorial of a number is:" + factorial(5))
  //determine the type of variable in scala using Manifest
  def getType[T: Manifest](t: T): Manifest[T] = manifest[T]
  val productInfo = (21677612, "Samsung S5", true, 48.270)
  println(getType(productInfo))
  //function printType
  def printType[T](x: T)(implicit tag: TypeTag[T]): Unit = println(tag.tpe.toString())
  printType(List[Int](123, 1234, 12342, 382))
  printType(("Syed", true, 12383, 0.128))
  //scala variable arguments
  def computeSum(args: Int*): Int = {
    var result = 0
    for (arg <- args) { result += arg }
    result
  }
  println("compute the sum of the numbers:" + computeSum(12, 14, 16) + " " + computeSum(12, 41, 1278, 237))
}
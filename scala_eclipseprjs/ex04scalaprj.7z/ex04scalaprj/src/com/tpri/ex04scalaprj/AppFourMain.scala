package com.tpri.ex04scalaprj
import scala.collection.immutable
import scala.collection.mutable.ArrayBuffer
import scala.util.Sorting._
import scala.annotation.tailrec

/**
 * Scala lists,Arrays and for comprehension and yield statement
 */
object AppFourMain extends App {
  
  var print=for(i<-1 to 10) yield i
  for(j<-print) println(j)
  
  
  var fruits = ArrayBuffer[String]()
  fruits+="Banana"
  fruits +="Apple"
  fruits +="Orange"
  fruits +="Kiwi"
  fruits +="Mango"
  println(fruits(0))
  println(fruits.length)
  val fruitBasket = Array("Mango","kiwi","papaya","cherry", "apple", "banana","Orange")
  scala.util.Sorting.quickSort(fruitBasket)
  println(fruitBasket)
  
  val mylist= List.range(1,50)
  println(sum(mylist))
  println(sum2(mylist))
  println(sum3(mylist))
  //recursive function
  // yields a "java.lang.stackOverflowerror" with large lsits 
  def sum(temps: List[Int]): Int = temps match { 
    case Nil => 0
    case x :: tail => x + sum(tail)
  }
  
  //tail recursion demo 
  def sum2(temps:List[Int]):Int={
    @tailrec
    def sumAccumulator(temps:List[Int],accum:Int):Int={
      temps match{
        case Nil => accum
        case x :: tail => sumAccumulator(tail,accum +x)
      }
    }
    sumAccumulator(temps,0)
  }
  
  //alternative approach 
  def sum3(rems:List[Int]):Int={
    if(rems.isEmpty)0
    else rems.head + sum3(rems.tail)
  }
  
  
  val stockPrice=List(22,33,14,6,19,23)
  println(computeProduct(stockPrice))
  println(otherProduct(stockPrice))
  def computeProduct(temps:List[Int]):Int= temps match{
    case Nil=>1
    case x :: tail => x*computeProduct(tail)
  }
  
  def otherProduct(rems:List[Int]):Int={
    @tailrec 
    def productAccumulator(rems:List[Int], accum:Int):Int={
      rems match{
        case Nil =>accum
        case x :: tail => productAccumulator(tail,accum*x)
        
      }
    }
    productAccumulator(rems,1)
  }
  
  
  //compute fibonacci
  
  def computeFibonacci(prevNo:Int, prev:Int){
    val next = prevNo+prev
    println(next)
    if(next>1000000)System.exit(0)
    computeFibonacci(prev,next)
  }
  
  println(computeFibonacci(1,2))
  
  
  
}
package com.tpri

object ex05scalaprj extends App {
  
 //using match 
  
  def getClassAsString(x:Any):String = x match{
    case s:String => s+"is a String"
    case i:Int => "Integer"
    case f:Float=>"Float"
    case d:Double=>"Double"
    case l:List[_]=>"List"
    case _=>"Unknown Type"
  }
  
  
  val myscores=Vector(1237,236,2637,374,2726,2828,1627,2637,374)
  val uScores=myscores.distinct
  
  //convert to set 
  val turnSet=myscores.toSet
  println(uScores)
  println(turnSet)
  
  val twitterList=List("Syed","Awase","Syed","Ameese","Syed","Azeez","Rayyan","Aicy","Abu")
  println(twitterList.distinct)
  
  val stackValues = Array.range(1,7)
  val stackList=List.range(0,5)
  val stackVec=Vector.range(0,10,2)
  val zone=(0 until 10).toArray
  val zombiList=1 to 10 by 2 toList 
  val rays=(1 to 10).by(2).toList 
  
  val setRooms=(0 until 10 by 2).toSet 
  val coord=(1 to 5).map(_*3.0)
  
  
  val posWords=Array("You", "Know","Hello","You","Fool","I","Love","You","Come","On","Enjoy","the","joy","ride")
  println(posWords.mkString(" "))
  println(posWords.mkString("\n"))
  println(posWords.mkString("."))
  
  val mygoals=List(List(2,3,5,8,11),List(34,23,13,15))
  println(mygoals)
  val flattenResult=mygoals.flatten
  
  val collectiveArr=Array(twitterList, posWords)
  println(collectiveArr)
  val z=Vector(Some(1),None,Some(3),None)
  z.flatten
  
  
  //intersection demo 
  val indScore=Array(12,13,45,56.67,27,99,120,71,13)
  val pakScore=Array(45,67,98,78,67,45,13,12,56,12)
  val sameScore=indScore.intersect(pakScore)
  println(sameScore)
  println(pakScore.union(indScore).distinct)
  val diffScore = indScore diff pakScore
  
  
  val c=List(12,34,23,113,124)
  val h=List(17,236,84,92,93)
  val f=c ::: h
  println(f)
  
  
  
}
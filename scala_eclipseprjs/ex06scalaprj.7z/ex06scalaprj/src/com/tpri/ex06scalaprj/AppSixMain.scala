package com.tpri.ex06scalaprj

object AppSixMain extends App {
  
  
  val syed=new Customer("Awase Khirni","Syed","awasekhirni@gmail.com","9035433124","227, 5 A Main HRBR,Bangalore")
  syed.CustomerInfo()
  
  val gmail=new MailAccount("awasekhirni@gmail.com","awaskhirni","test123","gmailbox","imap.mail.google.com",1,"imaps","awase")
  println(gmail.toString())
  
}
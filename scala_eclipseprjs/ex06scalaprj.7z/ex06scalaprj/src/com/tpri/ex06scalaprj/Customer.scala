package com.tpri.ex06scalaprj

import scala.beans.BeanProperty

class Customer(@BeanProperty var firstName:String,
                @BeanProperty var lastName:String,
                @BeanProperty var email:String,
                @BeanProperty var mobile:String,
                @BeanProperty var address:String){
  def CustomerInfo():Unit={
    println(firstName,lastName,email,mobile,address)
    
  }
  
  
  
  
}
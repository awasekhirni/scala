package com.tpri.ex06scalaprj

import scala.beans.BeanProperty

class MailAccount (@BeanProperty var accountName:String=null,
  @BeanProperty var username:String=null,
  @BeanProperty var password:String=null,
  @BeanProperty var mailbox:String=null,
  @BeanProperty var imapServerUrl:String = null,
  @BeanProperty var minutesBetweenChecks:Int=0,
  @BeanProperty var protocol:String=null,
  @BeanProperty var usersOfInterest:String=null
  ) {
  
}
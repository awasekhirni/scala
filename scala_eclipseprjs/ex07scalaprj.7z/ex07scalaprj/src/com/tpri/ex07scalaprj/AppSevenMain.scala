package com.tpri.ex07scalaprj

import com.tpri.ex07scalaprj.model.Product

object AppSevenMain extends App {
  val samsung= new Product("Samsung Galaxy S5","845 quadcore processor","samsung.jpg",56000,true)
  println(samsung.toString())
  
  val nokia=new Product("nokia3310",3800)
  println(nokia.toString())
  
  val iphone=new Product("Apple Iphone","845 quadcore processor",84000)
  println(iphone.toString())
  
}
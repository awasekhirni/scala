package com.tpri.ex07scalaprj.model


// primary constructor is defined for the class
class Product (val productName:String, val productDesc:String,val productImg:String, val productPrice:Int,val productIsOnSale:Boolean=true){
  
  //secondary constructor
  def this(productName:String, productPrice:Int){
    this(productName,"","",productPrice,true)
    println("productDesc, productImg and productIsOnSale are given")
  }
  
  //another constructor
  def this(productName:String, productDesc:String, productPrice:Int){
  this(productName,productDesc,"",productPrice,true)
  println("productImage and productIsOnSale are given")
  }
  
  
  //toString method 
  override def toString:String={
    return "%s %s %s %d %s".format(productName,productDesc,productImg,productPrice,productIsOnSale)
  }
  
}
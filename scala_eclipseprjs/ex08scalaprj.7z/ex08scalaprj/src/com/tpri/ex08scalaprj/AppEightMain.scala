package com.tpri.ex08scalaprj

import com.tpri.ex08scalaprj.model.MountainBike
import com.tpri.ex08scalaprj.model.ProductType
import scala.collection.mutable.ArrayBuffer

object AppEightMain  {
  
  
  def main(args:Array[String]){
    val bike= new MountainBike(12,23,19)
    bike.addHeight(12)
    bike.speedUp(20)
    bike.applyBreak(7)
    
//    val nokia=new Product(13342,"Nokia 6","Phones",48000)
//    
//    val canon=new Product(26462,"Canon Pixma Printer", "Printer",14000)
//    
//    val samsung=new Product(363462,"Samsung SmartTv", "TV",34000)
//    
//    val electronics=ArrayBuffer.empty[ProductType]
//    electronics.append(nokia)
//    electronics.append(canon)
//    electronics.append(samsung)
//    //foreach 
//    electronics.foreach(product=>println(product.toString()))
    
    
  }
}
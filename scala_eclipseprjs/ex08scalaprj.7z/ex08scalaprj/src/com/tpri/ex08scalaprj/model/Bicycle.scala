package com.tpri.ex08scalaprj.model

class Bicycle (val gearVal:Int, val speedVal:Int) {
  
  var gear:Int=gearVal
  var speed:Int=speedVal
  
  def applyBreak(decrement:Int){
    gear=gear-decrement
    println("new gear values is:"+gear)
  }
  
  def speedUp(increment:Int){
    speed=speed+increment
    println("new speed value:"+speed)
  }
}
package com.tpri.ex08scalaprj.model

case class Company(companyId:Int,companyName:String,companyUrl:String, companyRegOff:String, incYear:Int, incMonth:Int) {
  
}
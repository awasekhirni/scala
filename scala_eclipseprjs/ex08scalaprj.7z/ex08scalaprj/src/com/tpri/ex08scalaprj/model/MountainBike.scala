package com.tpri.ex08scalaprj.model

class MountainBike(override val gearVal:Int, override val speedVal:Int, val startHeightVal:Int)extends Bicycle(gearVal,speedVal){
  
  var startHeight:Int=startHeightVal
  
  def addHeight(newVal:Int){
    startHeight=startHeight+newVal
    println("new startHeight:"+startHeight)
  }
}
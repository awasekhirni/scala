package com.tpri.ex08scalaprj.model

case class Product(val productId:Int, val productName:String,val typeName:String,val productPrice:Int) extends ProductType {
  
}
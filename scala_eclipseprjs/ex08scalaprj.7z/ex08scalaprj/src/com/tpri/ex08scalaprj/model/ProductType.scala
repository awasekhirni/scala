package com.tpri.ex08scalaprj.model

trait ProductType {
  
  val typeName:String
}
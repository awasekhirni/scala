package com.tpri.ex09scalaprj

trait Cell {
  def save(x:Int)
  def retrieve
}
package com.tpri.ex09scalaprj

object NineMain extends App {
  val cell = new StandardCell(3)
    with Similar{
    def isSimilar(x:Int)=state==x
  }
}
package com.tpri.ex09scalaprj

trait Similar {
  def isSimilar(x:Int):Boolean
  def isNotSimilar(x:Int):Boolean = !isSimilar(x)
}
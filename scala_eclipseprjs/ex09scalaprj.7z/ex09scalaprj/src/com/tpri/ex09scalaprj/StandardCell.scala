package com.tpri.ex09scalaprj

class StandardCell(protected var state:Int) extends Cell {
  def save(x:Int)=state=x
  def retrieve = state
}
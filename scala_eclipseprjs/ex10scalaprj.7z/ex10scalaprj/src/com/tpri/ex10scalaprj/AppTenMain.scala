package com.tpri.ex10scalaprj

object AppTenMain extends App {
  println("Implementing using Traits, Classes")
}
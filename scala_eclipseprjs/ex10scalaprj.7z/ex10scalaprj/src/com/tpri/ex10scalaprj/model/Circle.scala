package com.tpri.ex10scalaprj.model

class Circle extends Shape{
  def draw=println("printing a circle")
}
package com.tpri.ex10scalaprj.model

class Line extends Shape {
  def draw = println("Printing a line")
}
package com.tpri.ex10scalaprj.model

case class Painting(){
  
}
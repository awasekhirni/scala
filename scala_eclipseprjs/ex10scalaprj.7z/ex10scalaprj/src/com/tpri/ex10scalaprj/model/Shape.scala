package com.tpri.ex10scalaprj.model

trait Shape {
  def draw
}
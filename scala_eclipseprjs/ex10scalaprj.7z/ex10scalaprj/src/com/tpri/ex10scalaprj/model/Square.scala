package com.tpri.ex10scalaprj.model

class Square  extends Shape{
  def draw=println("Printing 4 straightline to make a Square")
}
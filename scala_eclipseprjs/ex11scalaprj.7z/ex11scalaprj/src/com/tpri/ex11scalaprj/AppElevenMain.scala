package com.tpri.ex11scalaprj

import java.util.Date
import com.tpri.ex11scalaprj.model.TradeContract
import com.tpri.ex11scalaprj.model.LoanContract
import com.tpri.ex11scalaprj.model.Delegator
import com.tpri.ex11scalaprj.model.TDelegator

object AppElevenMain extends App {
  val c1=LoanContract("CitiBank",Seq("Awase"), 12387123,0.05, new Date(),3,"monthly")
  println(c1)
  println(c1.totalRepayable)
  println("**********************************")
  val c2=TradeContract("HDFCBank","TPRI", 1898398289, 1.4,"Sadath", new Date(), 10)
  println(c2)
  c2.floatingRate=0.7
  
  
  //delegation demo 
  val d=Delegator()
  println(d)
  d.print
  
  //using traits for delegation demo 
  val td=TDelegator()
  println(td)
  td.print
}
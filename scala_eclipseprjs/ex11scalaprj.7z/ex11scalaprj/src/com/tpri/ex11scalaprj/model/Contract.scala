package com.tpri.ex11scalaprj.model

trait Contract {
  
}
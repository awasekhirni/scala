package com.tpri.ex11scalaprj.model

case class Delegate() {
  def printer=println("Delegated to me to say Hello to you!")
}
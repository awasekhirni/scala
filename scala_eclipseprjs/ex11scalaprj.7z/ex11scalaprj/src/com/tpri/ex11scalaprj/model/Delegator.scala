package com.tpri.ex11scalaprj.model




case class Delegator() {
  private val delegate = Delegate()
  def print = delegate.printer
  override def toString = "Delegator"
}
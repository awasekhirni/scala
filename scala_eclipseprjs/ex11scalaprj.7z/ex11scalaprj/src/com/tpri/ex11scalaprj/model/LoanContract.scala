package com.tpri.ex11scalaprj.model

import java.util.Date

case class LoanContract(val lender:String, 
                        val borrowers:Seq[String],
                        val amount:Double,
                        val rate:Double,
                        val startDate:Date,
                        val duration:Int,
                        val repayments:String ) extends Contract {
  def totalRepayable={
    amount*Math.pow((1+rate),duration)
  }
}
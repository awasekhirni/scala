package com.tpri.ex11scalaprj.model

trait TDelegate {
  def printer=println("Using Traits to Delegate Work!")
}
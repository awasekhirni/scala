package com.tpri.ex11scalaprj.model

case class TDelegator() extends TDelegate {
  def print=printer
}
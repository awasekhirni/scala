package com.tpri.ex11scalaprj.model

import java.util.Date

case class TradeContract(val buyer:String, val seller:String, val notional:Double, val fixedRate:Double, val floatingIndex:String, val effectiveDate:Date, val term:Int) extends Contract{
  
  var floatingRate:Double=0.0
  
}
package com.tpri.ex12scalaprj

import com.tpri.ex12scalaprj.model.BasicIntQueue
import com.tpri.ex12scalaprj.model.Doubling
import com.tpri.ex12scalaprj.model.Incrementing



object AppTwelveMain extends App {
  
val queue=new BasicIntQueue with Doubling
queue.put(100)
println(queue.get())

val otherqueue=new BasicIntQueue with Incrementing with Doubling
otherqueue.put(500)
println(otherqueue.get())
}
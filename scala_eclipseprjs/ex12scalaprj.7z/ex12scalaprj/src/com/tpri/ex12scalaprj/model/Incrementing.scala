package com.tpri.ex12scalaprj.model

trait Incrementing extends IntQueue{
  abstract override def put(x:Int){
    super.put(x+50)
  }
}
package com.tpri.ex12scalaprj.model

abstract class IntQueue {
  def get():Int
  def put(x:Int)
}
package com.tpri.ex15dpscalaprjfdp

import com.tpri.ex15dpscalaprjfdp.model.ComputerFactory


object FifteenAppMain extends App {
  println("Scala Design Patterns Demo -Factory Design Pattern")
 val dellLatitude=ComputerFactory("laptop","16GB","512GB SSD","i7 QuadCore 3.1GhZ")
 val dellPrecision=ComputerFactory("server","64GB","2TB", "i7 OctaCore 3.1Ghz")
 println("ComputerFactory LaptopConfiguration:"+dellLatitude.toString())
 println("ComputerFactory ServerConfiguration:"+dellPrecision.toString())
 
}
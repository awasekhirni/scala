package com.tpri.ex15dpscalaprjfdp.model

object ComputerFactory {
   def apply(compType:String,ram:String,hdd:String,cpu:String)=compType.toUpperCase match{
    case "LAPTOP"=> new com.tpri.ex15dpscalaprjfdp.model.Laptop(ram,hdd,cpu)
    case "SERVER"=> new com.tpri.ex15dpscalaprjfdp.model.Server(ram,hdd,cpu)
  }
}
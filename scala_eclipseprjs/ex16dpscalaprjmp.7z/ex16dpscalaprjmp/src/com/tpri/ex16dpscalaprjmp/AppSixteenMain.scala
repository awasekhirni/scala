package com.tpri.ex16dpscalaprjmp

import com.tpri.ex16dpscalaprjmp.model.IAlertMediator
import com.tpri.ex16dpscalaprjmp.model.AlertMediatorImpl
import com.tpri.ex16dpscalaprjmp.model.AlertObserver
import com.tpri.ex16dpscalaprjmp.model.FileAlertSubscriber
import com.tpri.ex16dpscalaprjmp.model.OracleAlertSubscriber
import com.tpri.ex16dpscalaprjmp.model.NoSQLAlertSubscriber
import com.tpri.ex16dpscalaprjmp.model.DynamicAlert
import com.tpri.ex16dpscalaprjmp.model.ThresholdAlert

object AppSixteenMain extends App {
  val alertMediator:IAlertMediator=new AlertMediatorImpl()
  val file:AlertObserver=new FileAlertSubscriber()
  val oracle:AlertObserver=new OracleAlertSubscriber()
  val nosql:AlertObserver=new NoSQLAlertSubscriber()
  
  alertMediator.addSubscriberToDynamicAlert(file)
  alertMediator.addSubscriberToDynamicAlert(oracle)
  alertMediator.addSubscriberToThresholdAlert(nosql)
  
  val dynamicAlert:DynamicAlert=new DynamicAlert(100,200,300,"PW",5,"dynamic")
  val thresholdAlert:ThresholdAlert=new ThresholdAlert(100,200,300,"PW",5,"threshold")
  
  alertMediator.publishAlert(dynamicAlert)
  alertMediator.publishAlert(thresholdAlert)
  
}
package com.tpri.ex16dpscalaprjmp.model

trait Alert {
  def alertType:String
}
package com.tpri.ex16dpscalaprjmp.model

trait AlertObserver {
  def publish(alert:Alert):Unit
}
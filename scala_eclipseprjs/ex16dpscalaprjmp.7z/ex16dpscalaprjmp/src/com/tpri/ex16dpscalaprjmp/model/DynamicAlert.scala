package com.tpri.ex16dpscalaprjmp.model

class DynamicAlert(var elementId:Int,var metricMetadataId:Int, var metricMetadataHourlyId:Int,var durationType:String, var durationInterval:Int, var alertType:String) extends Alert {
  
}
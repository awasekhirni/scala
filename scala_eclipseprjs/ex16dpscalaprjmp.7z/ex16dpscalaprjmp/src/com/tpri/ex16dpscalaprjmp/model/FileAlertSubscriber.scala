package com.tpri.ex16dpscalaprjmp.model

class FileAlertSubscriber () extends AlertObserver{
  
  def publish(alert:Alert):Unit={
    println("FileAlertSubscriber has been called")
  }
}
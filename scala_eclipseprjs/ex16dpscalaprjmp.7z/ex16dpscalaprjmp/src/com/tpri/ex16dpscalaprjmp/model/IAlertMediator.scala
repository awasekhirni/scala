package com.tpri.ex16dpscalaprjmp.model

trait IAlertMediator {
  def addSubscriberToDynamicAlert(alertobserver:AlertObserver)
  def addSubscriberToThresholdAlert(alertobserver:AlertObserver)
  def publishAlert(alert:Alert)
}
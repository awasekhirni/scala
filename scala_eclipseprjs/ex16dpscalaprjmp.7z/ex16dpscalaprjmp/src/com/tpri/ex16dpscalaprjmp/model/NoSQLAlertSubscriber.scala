package com.tpri.ex16dpscalaprjmp.model

class NoSQLAlertSubscriber() extends AlertObserver {
  def publish(alert:Alert):Unit={
    println("NoSQLAlert Subscriber called")
  }
}
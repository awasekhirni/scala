package com.tpri.ex16dpscalaprjmp.model

class OracleAlertSubscriber() extends AlertObserver {
  def publish(alert:Alert):Unit={
    println("Oracle Alert Subscriber called")
  }
}
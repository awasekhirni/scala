package com.tpri.ex17dpscalaprjmp

import com.tpri.ex17dpscalaprjmp.model.FanoutChatMediator
import com.tpri.ex17dpscalaprjmp.model.OnlineChatMember

object AppSeventeenMain extends App {
  val chat = new FanoutChatMediator()
  
  val syed= new OnlineChatMember("Awase",chat)
  val naira = new OnlineChatMember("Naira",chat)
  
  syed.send("Hello! Naira, How are you?")
  syed.send("How did you do in the exams?")
  
  naira.send("Hello! Abba, i am good! stood first in class")
  val simra=new OnlineChatMember("Simra",chat)
  simra.send("Can we go and see the croods tonight")
  
}
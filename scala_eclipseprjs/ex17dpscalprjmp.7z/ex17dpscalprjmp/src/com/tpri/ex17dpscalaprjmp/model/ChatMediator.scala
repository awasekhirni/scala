package com.tpri.ex17dpscalaprjmp.model

trait ChatMediator {
  def join(newMember:ChatMember)
  def send(message:String,sender:ChatMember)
}
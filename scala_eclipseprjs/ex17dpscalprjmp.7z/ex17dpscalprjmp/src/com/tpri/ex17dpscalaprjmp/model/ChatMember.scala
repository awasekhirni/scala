package com.tpri.ex17dpscalaprjmp.model

trait ChatMember {
  def receive(message:String)
  def send(message:String)
}
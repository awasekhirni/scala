package com.tpri.ex17dpscalaprjmp.model

class FanoutChatMediator extends ChatMediator {
  var chatMembers:List[ChatMember]=List()
  
  def join(newMember:ChatMember)={
    chatMembers=newMember::chatMembers
  }
  
  override def send(message:String, sender:ChatMember):Unit={
    chatMembers.filter(member=>member ne sender).foreach(member=>member.receive(message))
  }
}
package com.tpri.ex17dpscalaprjmp.model


class OnlineChatMember (name:String,chatMediator:ChatMediator) extends ChatMember{
  chatMediator.join(this)
  override def receive(message:String)=println(name+"received message"+message)
  override def send(message:String)=chatMediator.send(message,this)
}
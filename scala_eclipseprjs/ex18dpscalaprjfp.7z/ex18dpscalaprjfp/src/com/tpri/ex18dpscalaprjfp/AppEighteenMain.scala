package com.tpri.ex18dpscalaprjfp

import com.tpri.ex18dpscalaprjfp.model.AnimalFactory
import com.tpri.ex18dpscalaprjfp.model.DogFactory
import com.tpri.ex18dpscalaprjfp.model.CatFactory

object AppEighteenMain extends App {
  
  println("Scala Factory Pattern Demo")
  val dogFactory:AnimalFactory = new DogFactory
  val catFactory:AnimalFactory= new CatFactory

  println("One type ---")
  val puddle=dogFactory.getAnimal("germanshepherd")
  val lassie=dogFactory.getAnimal("husky")
  val bruno=dogFactory.getAnimal("dobberman")
   
  puddle.speak
  lassie.speak
  bruno.speak
  
  println("the other type --- cats")
  val lia=catFactory.getAnimal("persiancat")
  lia.speak

}
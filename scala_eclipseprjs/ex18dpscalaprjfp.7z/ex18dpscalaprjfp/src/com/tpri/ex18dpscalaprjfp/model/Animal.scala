package com.tpri.ex18dpscalaprjfp.model

trait Animal {
  def speak:Unit
  def eat:Unit
  def run:Unit
}
package com.tpri.ex18dpscalaprjfp.model

trait AnimalFactory {
  def getAnimal(criteria:String):Animal
}
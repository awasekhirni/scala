package com.tpri.ex18dpscalaprjfp.model

class BengalCat extends Cat {
 def speak=println("Meow-Meow! I am a BengalCat")
  def eat=println("I like to drink milk")
  def run=println("I like to play with lights and like fur ball")
  
}
package com.tpri.ex18dpscalaprjfp.model

class CatFactory extends AnimalFactory {
  def getAnimal(criteria:String)= criteria match{
    case "bengalcat" => new BengalCat
    case "persiancat"=> new PersianCat
    case "siamesecat"=> new SiameseCat
  }
}
package com.tpri.ex18dpscalaprjfp.model

trait Dog extends Animal{
  
}
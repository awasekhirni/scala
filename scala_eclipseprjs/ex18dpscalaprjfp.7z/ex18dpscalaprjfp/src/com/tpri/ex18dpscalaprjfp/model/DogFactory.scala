package com.tpri.ex18dpscalaprjfp.model

class DogFactory extends AnimalFactory {
  
  def getAnimal(criteria:String):Animal=criteria match{
    case "dobberman"=>new Dobberman 
    case "germanshepherd"=> new GermanShepherd
    case "husky"=> new Husky
  }
}
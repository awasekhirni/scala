package com.tpri.ex18dpscalaprjfp.model

class GermanShepherd extends Dog {
  
  def speak=println("WOOF WOOF- I am a german Shepherd")
  def eat=println("I like to eat from meat")
  def run=println("I like to go fetch the ball and catch and sniff criminals out")
  
}
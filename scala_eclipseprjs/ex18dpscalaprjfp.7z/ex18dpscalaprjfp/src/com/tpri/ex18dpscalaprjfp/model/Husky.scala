package com.tpri.ex18dpscalaprjfp.model

class Husky extends Dog {
    def speak=println("WOOF WOOF- I am a Siberian Husky")
  def eat=println("I like to eat from meat")
  def run=println("I like to go fetch the ball and catch and sniff criminals out")
  
}
package com.tpri.ex18dpscalaprjfp.model

class SiameseCat extends Cat {
  def speak=println("Meow-Meow! I am a SiameseCat")
  def eat=println("I like to drink milk")
  def run=println("I like to play with lights and like fur ball")
  
}
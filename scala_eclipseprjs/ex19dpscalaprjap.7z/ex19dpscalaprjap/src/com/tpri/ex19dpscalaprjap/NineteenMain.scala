package com.tpri.ex19dpscalaprjap

import com.tpri.ex19dpscalaprjap.model.FahrenheitConverter
import com.tpri.ex19dpscalaprjap.model.CelsiusIdentityConverter
import com.tpri.ex19dpscalaprjap.model.AirConditioner
import com.tpri.ex19dpscalaprjap.model.Celsius
import com.tpri.ex19dpscalaprjap.model.Fahrenheit

object NineteenMain extends App {
  
  println("Adapter Design pattern using Scala")
  
  implicit val fahrenheitToCelsius=new FahrenheitConverter
  implicit val celsiusIdentity=new CelsiusIdentityConverter

  val airConditioner = new AirConditioner()
  airConditioner.setTemperature(new Fahrenheit(78))
  airConditioner.setTemperature(new Celsius(23))

}
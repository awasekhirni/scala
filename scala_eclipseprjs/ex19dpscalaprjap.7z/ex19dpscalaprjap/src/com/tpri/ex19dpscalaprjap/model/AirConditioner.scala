package com.tpri.ex19dpscalaprjap.model

class AirConditioner {
   def setTemperature[T](degrees: T)(implicit ev: ToCelsius[T]): Unit = {
      val converter = implicitly[ToCelsius[T]]
      val asCelsius = converter.convert(degrees)
      println(s"Set to $asCelsius")
    }
}
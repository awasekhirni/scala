package com.tpri.ex19dpscalaprjap.model

case class Celsius (degrees:Double) {
  
}
package com.tpri.ex19dpscalaprjap.model

class CelsiusIdentityConverter extends ToCelsius[Celsius] {
  override def convert(source:Celsius):Celsius=source
}
package com.tpri.ex19dpscalaprjap.model

case class Fahrenheit(degrees:Double) {
  
}
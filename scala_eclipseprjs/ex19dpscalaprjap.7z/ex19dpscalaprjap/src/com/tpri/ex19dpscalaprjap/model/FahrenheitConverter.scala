package com.tpri.ex19dpscalaprjap.model

class FahrenheitConverter extends ToCelsius[Fahrenheit] {
  override def convert(source: Fahrenheit): Celsius = new Celsius((source.degrees - 32) * 5 / 9)
  }
package com.tpri.ex19dpscalaprjap.model

trait ToCelsius[From] {
  def convert(source:From):Celsius
}
package com.tpri.ex20dpscalaprjcor

import com.tpri.ex20dpscalaprjcor.model.Boss
import com.tpri.ex20dpscalaprjcor.model.Supervisor
import com.tpri.ex20dpscalaprjcor.model.Agent
import com.tpri.ex20dpscalaprjcor.model.Event

object TwentyMain extends App {
  println("Scala Design Pattern:Chain of Responsibility Demo")

  val boss = new Boss(None)
  val supervisor = new Supervisor(Some(boss))
  val agent = new Agent(Some(supervisor))
  println("Passing events")
  val events = Array(
    Event(1, "Technical support"),
    Event(2, "Billing query"),
    Event(1, "Product information query"),
    Event(3, "Bug report"),
    Event(5, "Police subpoena"),
    Event(2, "Enterprise client request"))
  events foreach { e: Event =>
    agent.handleEvent(e)
  }

}
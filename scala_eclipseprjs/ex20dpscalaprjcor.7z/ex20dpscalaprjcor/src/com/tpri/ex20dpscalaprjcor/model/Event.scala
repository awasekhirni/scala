package com.tpri.ex20dpscalaprjcor.model

case class Event(val level:Int, val title:String) {
  
}
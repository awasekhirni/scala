package com.tpri.ex20dpscalaprjcor.model

abstract class Handler {
  val successor:Option[Handler]
  def handleEvent(event:Event):Unit
}
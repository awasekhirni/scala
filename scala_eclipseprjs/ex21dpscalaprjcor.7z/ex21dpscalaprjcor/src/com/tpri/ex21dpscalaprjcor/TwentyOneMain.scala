package com.tpri.ex21dpscalaprjcor

import scala.annotation.meta.field
import com.tpri.ex21dpscalaprjcor.model.Paginate
import com.tpri.ex21dpscalaprjcor.model.Sort
import com.tpri.ex21dpscalaprjcor.model.SortCommand
import com.tpri.ex21dpscalaprjcor.model.PaginateCommand
import com.tpri.ex21dpscalaprjcor.model.Item

object TwentyOneMain extends App {
  println("Scala design patterns: Chain of Responsibility")
  
  val page = Paginate(offset=10, limit=4)
  val sort=Sort(field=Some("key"))
  
  val pagination = new PaginateCommand(page,None)
  val sorting= new SortCommand(sort,Some(pagination))
  
  val data = List(
      Item(3, "milk"),
      Item(8, "eggs"),
      Item(10, "choclates"),
      Item(2, "juice"),
      Item(1, "bread"),
      Item(11, "cookies"),
      Item(4, "carrot"),
      Item(6, "biscuit"),
      Item(13, "book"),
      Item(7, "pen"),
      Item(5, "clip"),
      Item(9, "stickie"),
      Item(12, "banana")
    )

    val processed = sorting.handleData(data)
    println("page: " + processed)
  
}
package com.tpri.ex21dpscalaprjcor.model

abstract class ChainofCommand {
  val successor:Option[ChainofCommand]
  def handleData(data:List[Item]):List[Item]={
    successor match{
      case Some(x:ChainofCommand) => x.handleData(data)
      case None=> data
    }
  }
}
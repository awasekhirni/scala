package com.tpri.ex21dpscalaprjcor.model

case class Paginate(offset:Int, limit:Int) {
  
}
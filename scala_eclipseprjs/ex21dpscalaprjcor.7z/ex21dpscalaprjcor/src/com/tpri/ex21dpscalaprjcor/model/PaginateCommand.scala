package com.tpri.ex21dpscalaprjcor.model

class PaginateCommand(val page: Paginate, val successor: Option[ChainofCommand]) 
    extends ChainofCommand {


  override def handleData(data: List[Item]): List[Item] = {
    val paged = data
      .drop(page.offset)
      .dropRight(data.size - (page.offset + page.limit))

    super.handleData(paged)
  }
}
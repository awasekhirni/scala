package com.tpri.ex21dpscalaprjcor.model

case class Sort(field:Option[String],isAscending:Boolean=true) {
  
}
package com.tpri.ex21dpscalaprjcor.model

class SortCommand(val sort:Sort, val successor:Option[ChainofCommand]) extends ChainofCommand{
  
   override def handleData(data: List[Item]): List[Item] = {
    val sorted = sort.field.getOrElse("none") match {
      case "key" => data.sortWith(_.key > _.key)
      case "value" => data.sortWith(_.value > _.value)
      case "none" => data.sortWith(_.key > _.key)
    }

    val ordered = sort.isAscending match {
      case true => sorted.reverse
      case false => sorted
    }

    super.handleData(ordered)
  }
}
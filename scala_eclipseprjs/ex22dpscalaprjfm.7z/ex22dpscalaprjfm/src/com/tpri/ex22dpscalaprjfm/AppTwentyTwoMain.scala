package com.tpri.ex22dpscalaprjfm

import com.tpri.ex22dpscalaprjfm.model.ProductFactory

object AppTwentyTwoMain extends App {
  println("Scala design patterns: Factory Method")
  val oneProduct=ProductFactory.createProduct("Phone")
  val twoProduct =ProductFactory.createProduct("Laptop")
  println(oneProduct.toString())
  println(twoProduct.toString())
}
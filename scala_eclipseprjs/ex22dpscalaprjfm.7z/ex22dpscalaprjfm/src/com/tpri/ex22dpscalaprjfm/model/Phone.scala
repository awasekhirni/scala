package com.tpri.ex22dpscalaprjfm.model

case class Phone(private var price:Float) extends Product {
  def getPrice:Float=price
  def setPrice(price:Float)=this.price=price
  override def getProductType:String="Phone"
  
}
package com.tpri.ex22dpscalaprjfm.model

trait Product {
  def getPrice:Float
  def setPrice(price:Float)
  def getProductType:String={
    "Unknown Product"
  }
}
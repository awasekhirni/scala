package com.tpri.ex22dpscalaprjfm.model

object ProductFactory {
  def createProduct(kind : String): Product = kind match{
  
    case "Phone"=> Phone(36000.0F)
    case "Laptop"=>Laptop(98000.34F)
    
  }
}

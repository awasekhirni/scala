package com.tpri.ex23dpscalaprjbp

import com.tpri.ex23dpscalaprjbp.model.Chef

object TwentyThreeMain extends App {
  
  val italianChef=new Chef().withDough("cross").withTopping("olive+peparonni+salami+chicken tandoori").withSauce("Hot")
  
  val italianPizza=italianChef.build 
  println("Italian Pizza:"+italianPizza)
  
}
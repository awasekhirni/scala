package com.tpri.ex23dpscalaprjbp.model

class Chef extends PizzaBuilder {
  var dough:String=""
  var sauce:String=""
  var topping:String=""
  
  override def withDough(dough:String):PizzaBuilder={
    this.dough=dough
    this
  }
  
  
  override def withSauce(sauce:String):PizzaBuilder={
    this.sauce=sauce
    this
  }
  
  
  override def withTopping(topping:String):PizzaBuilder={
    this.topping=topping
    this
  }
  
  override def build:Product = new Pizza(this)
}
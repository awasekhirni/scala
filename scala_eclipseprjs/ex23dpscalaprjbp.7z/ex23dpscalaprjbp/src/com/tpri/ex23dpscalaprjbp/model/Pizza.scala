package com.tpri.ex23dpscalaprjbp.model

class Pizza(builder:PizzaBuilder) extends Product {
  val dough:String=builder.dough
  val sauce:String=builder.sauce 
  val topping:String = builder.topping 
  
  override def toString:String={
    "Dough:" + dough + " Topping:" + topping + " Sauce:" + sauce
  }
}
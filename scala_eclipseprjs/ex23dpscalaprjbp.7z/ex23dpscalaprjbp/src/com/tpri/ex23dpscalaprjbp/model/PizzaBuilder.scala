package com.tpri.ex23dpscalaprjbp.model

abstract class PizzaBuilder {
  var dough:String
  var sauce:String
  var topping:String
  
  def withDough(dough:String):PizzaBuilder
  def withSauce(sauce:String):PizzaBuilder
  def withTopping(topping:String):PizzaBuilder
  def build:Product
}
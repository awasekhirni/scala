package com.tpri.ex23dpscalaprjbp.model

abstract class Product {
  
}
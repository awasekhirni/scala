package com.tpri.ex24dpscalaprjbridgep

import com.tpri.ex24dpscalaprjbridgep.model.CachedPersistence
import com.tpri.ex24dpscalaprjbridgep.model.Persistence
import com.tpri.ex24dpscalaprjbridgep.model.FileStorage
import com.tpri.ex24dpscalaprjbridgep.model.SingleCache
import com.tpri.ex24dpscalaprjbridgep.model.DatabaseStorage

object AppTwentyFourMain extends App {
  
  println("Scala Design Patterns-Bridge pattern")
  val disk = new Persistence with FileStorage
  val db=new Persistence with DatabaseStorage
  val cachedDisk=new CachedPersistence with FileStorage with SingleCache
  println("""
      |Created three difference persistence things:
      |disk: Persistence with FileStorage
      |db: Persistence with DatabaseStorage
      |cachedDisk: CachedPersistence with FileStorage with SingleCache
      |For each in turn, perform two operations:
      |1. save("foo", "bar")
      |2. load("foo")
      """.stripMargin)

    println("disk")
    disk.save("foo", "bar")
    disk.load("foo")

    println("database")
    db.save("foo", "bar")
    db.load("foo")

    println("cached disk")
    cachedDisk.save("foo", "bar")
    cachedDisk.load("foo")
  
}
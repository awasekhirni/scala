package com.tpri.ex24dpscalaprjbridgep.model

trait CacheDriver {
  protected def get(key:String):Option[String]
  protected def put(key:String,value:String):Unit
}
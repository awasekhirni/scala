package com.tpri.ex24dpscalaprjbridgep.model

trait CachedPersistence extends Persistence{
  this:Storage with CacheDriver=>
    override def save(key:String,value:String):Unit={
      put(key,value)
      super.save(key,value)
    }
    
    override def load(key:String):String ={
      get(key) match{
        case Some(value)=>value
        case None=>{
          val value=super.load(key)
          put(key,value)
          value
        }
      }
    }
}


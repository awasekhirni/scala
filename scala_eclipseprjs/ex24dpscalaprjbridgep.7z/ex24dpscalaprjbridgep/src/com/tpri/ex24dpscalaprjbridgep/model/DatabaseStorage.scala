package com.tpri.ex24dpscalaprjbridgep.model

trait DatabaseStorage extends Storage{
  protected def read(key:String):String={
    println("Reading"+key+"from database")
    "mydbstorage"
  }
  protected def write(key:String,value:String):Unit={
    println("Writing"+value+"for"+key+"from database")
  }
}


package com.tpri.ex24dpscalaprjbridgep.model

trait FileStorage extends Storage{
  def read(key:String):String={
    println("Reading"+key+"from files")
    "mytest"
  }
  
  def write(key:String, value:String):Unit={
    println("Writing"+value+"for"+key+"from files")
  }
}
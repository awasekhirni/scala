package com.tpri.ex24dpscalaprjbridgep.model

trait Persistence {
  this:Storage=>
    def save(key:String,value:String):Unit=write(key,value)
    def load(key:String):String=read(key)
}
package com.tpri.ex24dpscalaprjbridgep.model

trait SingleCache extends CacheDriver {
  var cachedKey:String=_
  var cachedValue:String=_
  protected def put(key:String, value:String):Unit={
    cachedKey=key
    cachedValue=value
  }
  protected def get(key:String):Option[String]={
    if(key==cachedKey) Some(cachedValue) else None
  }
}
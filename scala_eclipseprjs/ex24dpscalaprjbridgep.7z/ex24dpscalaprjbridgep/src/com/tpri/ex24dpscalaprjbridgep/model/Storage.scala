package com.tpri.ex24dpscalaprjbridgep.model

trait Storage {
  protected def read(key:String):String
  protected def write(key:String,value:String):Unit
}
package com.tpri.ex26dpscalaprjflyweight

import com.tpri.ex26dpscalaprjflyweight.model.VendorCalibration
import com.tpri.ex26dpscalaprjflyweight.model.CalibrationFactory

object AppTwentySixMain extends App {
  
  val v="Data"
  val version="1.1.1"
  val vencal:VendorCalibration =CalibrationFactory(v)
  val cf:Option[Double]=vencal.getCalibration().get(version)
  val myvalue:Double = cf.getOrElse(1)
  
}
package com.tpri.ex26dpscalaprjflyweight.model

object CalibrationFactory {

  val cache: scala.collection.mutable.Map[String, VendorCalibration] = scala.collection.mutable.Map[String, VendorCalibration]()
  def apply(vendor: String): VendorCalibration =
    {

      val vendorCalibration: Option[VendorCalibration] = cache.get(vendor)

      val exist = vendorCalibration.getOrElse(false);

      if (exist == false) {
        if (vendor == "Frequency") {

          val cal = new FrequencyCalibration
          cache += ("Frequency" -> cal)
          return cal
        } else if (vendor == "CISCO") {
          val cal = new RangeCalibration
          cache += ("Range" -> cal)
          return cal

        } else if (vendor == "Data") {
          val cal = new DataCalibration
          cache += ("Data" -> cal)
          return cal

        } else {
          throw new IllegalArgumentException("Invalid argument.")
        }

      } else {
        return exist.asInstanceOf[VendorCalibration]
      }
    }
}
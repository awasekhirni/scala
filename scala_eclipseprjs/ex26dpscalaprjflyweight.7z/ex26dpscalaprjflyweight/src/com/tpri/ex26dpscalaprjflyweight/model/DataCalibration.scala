package com.tpri.ex26dpscalaprjflyweight.model

import java.io.File

class DataCalibration extends VendorCalibration {
  override def getCalibration(): Map[String, Double] =
    {
      return loadCorrectionFactor(new File("Data.csv"))
    }
}
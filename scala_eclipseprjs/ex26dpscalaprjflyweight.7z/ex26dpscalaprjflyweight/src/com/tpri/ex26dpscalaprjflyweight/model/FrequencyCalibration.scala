package com.tpri.ex26dpscalaprjflyweight.model

import java.io.File

class FrequencyCalibration extends VendorCalibration {
  override def getCalibration(): Map[String, Double] =
    {
      return loadCorrectionFactor(new File("frequency.csv"))
    }
}
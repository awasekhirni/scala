package com.tpri.ex26dpscalaprjflyweight.model

import java.io.File

trait VendorCalibration {
  def loadCorrectionFactor(file:File):Map[String,Double]={
    return Map()
  }
  
  def getCalibration():Map[String,Double]
}
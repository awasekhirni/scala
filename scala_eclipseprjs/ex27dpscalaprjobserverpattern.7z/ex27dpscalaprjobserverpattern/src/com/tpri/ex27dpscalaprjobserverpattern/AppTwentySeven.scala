package com.tpri.ex27dpscalaprjobserverpattern

import com.tpri.ex27dpscalaprjobserverpattern.model.PublishAlert
import com.tpri.ex27dpscalaprjobserverpattern.model.FileAlertSubscriber
import com.tpri.ex27dpscalaprjobserverpattern.model.DatabaseAlertSubscriber
import com.tpri.ex27dpscalaprjobserverpattern.model.Alert

object AppTwentySeven extends App {
  
  val filemonitor:FileAlertSubscriber = new FileAlertSubscriber(PublishAlert.getInstance)
  val dbmonitor:DatabaseAlertSubscriber= new DatabaseAlertSubscriber(PublishAlert.getInstance)
  PublishAlert.getInstance.notifyObservers(new Alert(2113,23,384,"Warning Alert Sent from Syed Awase",4))
}
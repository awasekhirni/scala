package com.tpri.ex27dpscalaprjobserverpattern.model

class Alert(var elementId:Int,
    var metricMetadataId:Int,var metricMetadataHourlyId:Int,
    var durationType:String, var durationInterval:Int){
  
}
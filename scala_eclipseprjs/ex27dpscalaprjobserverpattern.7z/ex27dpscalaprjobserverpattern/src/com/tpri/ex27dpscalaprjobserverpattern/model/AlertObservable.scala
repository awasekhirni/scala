package com.tpri.ex27dpscalaprjobserverpattern.model

trait AlertObservable {
  def register(observer:AlertObserver):Unit
  def unregister(observer:AlertObserver):Unit
  def notifyObservers(alert:Alert):Unit
}
package com.tpri.ex27dpscalaprjobserverpattern.model

import javafx.scene.control.Alert

trait AlertObserver {
  def publish(alert:Alert):Unit
}
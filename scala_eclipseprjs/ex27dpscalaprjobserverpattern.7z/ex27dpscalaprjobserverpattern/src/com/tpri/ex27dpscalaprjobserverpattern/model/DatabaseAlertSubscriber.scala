package com.tpri.ex27dpscalaprjobserverpattern.model

class DatabaseAlertSubscriber(observable:AlertObservable) extends AlertObserver {
  observable.register(this)
  def publish(alert:Alert):Unit={
    println("Database alert subscriber called!")
  }
}
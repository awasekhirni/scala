package com.tpri.ex27dpscalaprjobserverpattern.model

class FileAlertSubscriber(observable:AlertObservable) extends AlertObserver {
  observable.register(this)
  
  def publish(alert:Alert):Unit={
    println("File Alert Subscriber Called!")
  }
}
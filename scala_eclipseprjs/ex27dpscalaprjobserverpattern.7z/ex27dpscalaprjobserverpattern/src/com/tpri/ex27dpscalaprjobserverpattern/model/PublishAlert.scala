package com.tpri.ex27dpscalaprjobserverpattern.model

import scala.collection.mutable.ArrayBuffer

class PublishAlert extends AlertObservable {
  val observerList: ArrayBuffer[AlertObserver] = ArrayBuffer[AlertObserver]()

  def register(observer: AlertObserver): Unit = {
    observerList += observer
  }
  
  def unregister(observer:AlertObserver):Unit={
    val index:Int=observerList.indexOf(observer)
    observerList.remove(index)
  }
  
  
  def notifyObservers(alert:Alert):Unit={
    observerList.foreach{
      observer=> observer.publish(alert)
    }
  }
}

//companion object 
object PublishAlert{
  val pubalert:PublishAlert=new PublishAlert
  
  def getInstance():PublishAlert={
    pubalert
  }
}
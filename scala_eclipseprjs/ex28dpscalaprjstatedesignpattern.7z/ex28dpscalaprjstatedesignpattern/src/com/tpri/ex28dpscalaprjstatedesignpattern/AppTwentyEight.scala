package com.tpri.ex28dpscalaprjstatedesignpattern

import com.tpri.ex28dpscalaprjstatedesignpattern.model.TrafficSystem
import com.tpri.ex28dpscalaprjstatedesignpattern.model.YellowLight

object AppTwentyEight extends App {
  val ts: TrafficSystem = new TrafficSystem()
  while (true) {
    ts.displayState()
    if (ts.currentState.isInstanceOf[YellowLight]) {
      Thread.sleep(50)
      ts.changeState()
    } else {
      Thread.sleep(30)
      ts.changeState()
    }
  }
}
package com.tpri.ex28dpscalaprjstatedesignpattern.model

class GreenLight (trafficSystem:TrafficSystem,receiver:Receiver) extends State{
  def changeState()={
    receiver.off()
    trafficSystem.previousState=this
    trafficSystem.currentState=trafficSystem.yellow
  }
  
  def displayState()={
    receiver.on()
    
  }
}
package com.tpri.ex28dpscalaprjstatedesignpattern.model

class GreenReceiver extends Receiver {
  def on={
    println("Switching on green light:GREEN")
  }
  
  def off={
    println("Switching off green light:OFF")
  }
}
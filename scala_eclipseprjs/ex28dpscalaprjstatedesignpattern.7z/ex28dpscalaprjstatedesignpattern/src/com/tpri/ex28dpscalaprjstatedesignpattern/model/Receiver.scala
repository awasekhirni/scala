package com.tpri.ex28dpscalaprjstatedesignpattern.model

trait Receiver {
  def on()
  def off()
}
package com.tpri.ex28dpscalaprjstatedesignpattern.model

class RedReceiver extends Receiver{
  def on={
    println("Switching on red lights:RED")
  }
  
  def off={
    println("Switching off red light:OFF")
  }
}
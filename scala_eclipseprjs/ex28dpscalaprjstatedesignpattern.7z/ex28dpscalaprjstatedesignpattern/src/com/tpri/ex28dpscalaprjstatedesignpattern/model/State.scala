package com.tpri.ex28dpscalaprjstatedesignpattern.model

trait State {
  def changeState()
  def displayState()
}
package com.tpri.ex28dpscalaprjstatedesignpattern.model

class TrafficSystem {
  var initialReceiver: Receiver = new GreenReceiver()
  var green: State = new GreenLight(this, initialReceiver)
  var red: State = new RedLight(this, new RedReceiver)
  var yellow: State = new YellowLight(this, new YellowReceiver)
  var currentState: State = new GreenLight(this, initialReceiver)
  var previousState: State = new GreenLight(this, initialReceiver)

  def changeState() {
    currentState.changeState()
  }

  def displayState() {
    currentState.displayState()
  }
}
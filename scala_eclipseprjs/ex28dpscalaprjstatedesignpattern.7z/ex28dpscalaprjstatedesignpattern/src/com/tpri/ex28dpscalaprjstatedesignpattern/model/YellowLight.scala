package com.tpri.ex28dpscalaprjstatedesignpattern.model

class YellowLight(trafficSystem:TrafficSystem,receiver:Receiver) extends State {
  
  def changeState()={
    receiver.off()
    if(trafficSystem.previousState.isInstanceOf[GreenLight]){
      trafficSystem.currentState=trafficSystem.red
    }else{
      trafficSystem.currentState=trafficSystem.green
    }
  }
  
  
  def displayState()={
    receiver.on()
  }
}
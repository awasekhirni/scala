package com.tpri.ex28dpscalaprjstatedesignpattern.model

class YellowReceiver extends Receiver {
  def on={
    println("Switching on yellow light:YELLOW")
  }
  
  def off={
    println("Switching off yellow light:OFF")
  }
}